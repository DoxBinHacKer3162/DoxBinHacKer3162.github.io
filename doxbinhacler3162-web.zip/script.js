const heart = document.getElementById('heart');
const start = document.getElementById('start');
const question1 = document.getElementById('question1');
const yesBtn = document.getElementById('yesBtn');

heart.onclick = () => {
  start.classList.add('hidden');
  question1.classList.remove('hidden');
  moveYes();
};

function moveYes() {
  yesBtn.onmouseover = () => {
    const x = Math.random() * (window.innerWidth - 120);
    const y = Math.random() * (window.innerHeight - 60);
    yesBtn.style.left = `${x}px`;
    yesBtn.style.top = `${y}px`;
  };
}

function showHeart() {
  question1.classList.add('hidden');
  document.getElementById('heartMsg').classList.remove('hidden');
}

function showLinkQuestion() {
  document.getElementById('heartMsg').classList.add('hidden');
  document.getElementById('linkQuestion').classList.remove('hidden');
}

function checkAnswer() {
  const val = document.getElementById('userInput').value.toLowerCase().trim();
  if (val === 'neyin') {
    document.getElementById('linkQuestion').classList.add('hidden');
    document.getElementById('linkAnswer').classList.remove('hidden');
  } else {
    alert('İpucu tırnak içindeydi 😉');
  }
}

function showLove() {
  document.getElementById('linkAnswer').classList.add('hidden');
  document.getElementById('final').classList.remove('hidden');
}
